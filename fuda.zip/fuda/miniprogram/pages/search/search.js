// pages/search/search.js
var that
Page({

    /**
     * 页面的初始数据
     */
    data: {
        jinrihuati:[],
        jinrihuati1:[],
        chihewanle:[],
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        that = this
        
wx.cloud.database().collection('enjoys').get({
            success(res){
                console.log(res)
                console.log(res.data)
                that.setData({
                    jinrihuati1:res.data
                })
            }
        })

wx.cloud.database().collection('actions').get({
            success(res){
                console.log(res)
                console.log(res.data)
                that.setData({
                    jinrihuati:res.data
                })
            }
        })



    },
    tomyanswer(e){
        wx.navigateTo({
          url: '../essay/essay?id='+e.currentTarget.dataset.id,
        })
    },
    tomyenjoy(e){
        console.log(e.currentTarget.dataset.id)
        wx.navigateTo({

          url: '../essayenjoy/essayenjoy?id='+e.currentTarget.dataset.id,
        })
    },
    totopic(){
        wx.navigateTo({
          url: '../topic/topic',
        })
    },
    toenjoy(){
        wx.navigateTo({
          url: '../enjoy/enjoy',
        })
    },
    onClick(){
        wx.navigateTo({
            url:"../searchResult/searchResult"
        })
    }
})