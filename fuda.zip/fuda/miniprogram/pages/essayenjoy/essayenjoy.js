// pages/essay/essay.js
Page({


    data: {

    },
    onLoad: function (options) {
        console.log(options.id)
        var that=this;
        wx.cloud.database().collection('enjoys').doc(options.id).get({
            success(res){
                console.log(res)
            that.setData({
                action:res.data
            })
            
            }



        })



    },
bindViewTap: function(e){
       console.log(e)
    wx.navigateTo({
        
      url: '../commentsenjoys/commentsenjoys?id='+ e.currentTarget.dataset.id
  }) 
},
})