// pages/libraryUpload/libraryUpload.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    actionsList:[],
    flag: '参数'
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

    wx.cloud.database().collection('messages').where({_openid:app.globalData.opendid}).get({
      success:res=>{
        console.log(res)
        res.data.forEach(item=>{
          var tim=item.comment.time
          var d=new Date(tim);
          var year = d.getFullYear();
          var month = (d.getMonth() + 1)<10 ? "0"+(d.getMonth() + 1) :(d.getMonth() + 1)
          var day = d.getDate()
          var hour = d.getHours()
          var minute = d.getMinutes()
          var second = d.getSeconds()
          var time = year+"-"+month+"-"+day+" "+hour+":"+minute+":"+second
          item.time = time
        })

        this.setData({
          actionsList :res.data
        })
      }
    })
  },

  del: function(e){
   var that=this;
  console.log(e.currentTarget.dataset.flag)
    
 
    wx.cloud.database().collection('messages').doc(e.currentTarget.dataset.flag).remove({
      success(res){
        that.onLoad(),
        wx.showToast({
          title: '删除成功！',
        })

      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})