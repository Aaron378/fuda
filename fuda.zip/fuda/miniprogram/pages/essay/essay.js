// pages/essay/essay.js
const util=require("../../utils/util")
const app=getApp()
Page({


    data: {
        id:''
    },
    onLoad: function (options) {
        console.log(options.id)
        var that=this;
        wx.cloud.database().collection('actions').doc(options.id).get({
            success(res){
                console.log(res)
            that.setData({
                action:res.data,
                id:options.id
            })
            
            }



        })



    },
bindViewTap: function(e){
       console.log(e)
    wx.navigateTo({
        
      url: '../comments/comments?id='+ e.currentTarget.dataset.id
  }) 
},
getDetail(){
    var that=this;
    wx.cloud.database().collection('actions').doc(this.data.id).get({
        success(res){
            console.log(res)
            var action=res.data
            // action.time=util.formatTime(new Date(action.time))
            for(var l in action.priceList){
                if(action.priceList[l].openid==app.globalData.openid){
                    action.ispriced=true
                }
            }
            that.setData({
                action:res.data
            })
        }
    })
},
price:function(event)
{
    var that=this;
    if(app.globalData.userInfo==null){
        wx.navigateTo({
            url:'/pages/login/login',
        })
    }
    else{
        console.log(that.data.id)
    var that=this;
    wx.cloud.database().collection('actions').doc(that.data.id).get({
        success(res){
             console.log(res)
            var action=res.data
            var tag=false
            var index
            for(var l in action.priceList){
                if(action.priceList[l].openid==app.globalData.openid){
                    tag=true
                    index=l
                    break
                }
            }
            if(tag){
                action.priceList.splice(index,1)
                console.log(action)
                wx.cloud.database().collection('actions').doc(that.data.id).update({
                    data:{
                     priceList:action.priceList   
                    },
                    success(res){
                        console.log(res)
                        that.getDetail()
                    }
                })
            }
            else{
                var user={}
        //         user.nickName=app.globalData.userInfo.nickName
        //          user.faceImg=app.globalData.userInfo.avataUrl
           user.openid=app.globalData.openid
           action.priceList.push(user)
           console.log(action.priceList)
           wx.cloud.database().collection('actions').doc(that.data.id).update({
               data:{
                   priceList:action.priceList
               },
               success(res){
                   console.log(res)
                   wx.showToast({
                       title:'点赞成功',
                   })
                   that.getDetail()
               }
           })
            }
        }
    })
}
}
})