// pages/index/index.js
var that = this;
const app = getApp();

Page({
  /**     * 页面的初始数据     */
  data: {
    isLoading: false,
    list: [],
    actionsList: [],
    flag: '参数',

    imgUrls: [{
      link: '',
      url: 'cloud://cloud1-1gq2wa6591abf920.636c-cloud1-1gq2wa6591abf920-1308385870/111.png'
    }, {
      link: '',
      url: 'cloud://cloud1-1gq2wa6591abf920.636c-cloud1-1gq2wa6591abf920-1308385870/222.png'
    }, {
      link: '',
      url: 'cloud://cloud1-1gq2wa6591abf920.636c-cloud1-1gq2wa6591abf920-1308385870/333.png'
    }, {
      link: '',
      url: 'cloud://cloud1-1gq2wa6591abf920.636c-cloud1-1gq2wa6591abf920-1308385870/444.png'
    }],
    indicatorDots: true, //小点
    autoplay: true, //是否自动轮播
    interval: 5000, //间隔时间
    duration: 4000, //滑动时间
  },

  /**     * 生命周期函数--监听页面加载     */
  onLoad: function (options) {
    //获取云数据库数据
    let that = this
    wx.cloud.callFunction({
      name: "getlist",
      success(res) {
        console.log("请求成功", res)
        res.result.data.forEach(item => {
          var tim = item.time
          var d = new Date(tim);
          var year = d.getFullYear();
          var month = (d.getMonth() + 1) < 10 ? "0" + (d.getMonth() + 1) : (d.getMonth() + 1)
          var day = d.getDate()
          var hour = d.getHours()
          var minute = d.getMinutes() < 10 ? "0" + d.getMinutes() : d.getMinutes()
          var second = d.getSeconds() < 10 ? "0" + d.getSeconds() : d.getSeconds()
          var time = year + "-" + month + "-" + day
          item.time = time
        })
        that.setData({
          actionsList: res.result.data
        })
      },
      fail(err) {
        console.log("请求no", err)
      }
    })
  },
  //跳转
  toPost() {

    if (app.globalData.userInfo == null) {
      wx.navigateTo({
        url: '/pages/login/login',
      })

    } else {

      console.log(app.globalData.opendid)
      wx.navigateTo({
        url: '/pages/topicPost/topicPost',
      })
    }
  },
  toSearch() {
    wx.navigateTo({
      url: '/pages/search/search',
    })
  },
  toEssay(e) {
    console.log(e.currentTarget.dataset.id)
    wx.navigateTo({
      url: '/pages/essay/essay?id=' + e.currentTarget.dataset.id,
    })
  },
  upper: function () {
    if (this.data.isLoading)
      return
    wx.showNavigationBarLoading();
    this.data.isLoading = true;
    that = this;
    that.setData({
      list: that.data.list
    });
    //页面动画，不改
    setTimeout(function () {
      that.data.isLoading = false;
    }, 2000);
    setTimeout(function () {
      wx.hideNavigationBarLoading();
    }, 2000);

  },
  lower: function () {
    if (this.data.isLoading)
      return
    this.data.isLoading = true
    wx.showNavigationBarLoading();
    wx.showToast({
      title: '刷新中',
      icon: 'loading',
      duration: 2000
    });
    that = this;
    //页面动画，不改
    setTimeout(function () {
      that.onLoad();
      wx.showToast({
        title: '刷新成功',
        icon: 'success',
        duration: 2000
      })
      that.data.isLoading = false;
    }, 2000);
    setTimeout(function () {
      wx.hideNavigationBarLoading();
    }, 2000);

  },

})