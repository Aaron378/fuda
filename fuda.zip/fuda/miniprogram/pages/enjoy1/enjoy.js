// pages/topic/topic.js
//假造数据
var that;
Page({
    toEssay(){
        wx.navigateTo({
          url: '/pages/essay/essay',
        })
    },

    /**
     * 页面的初始数据
     */
    data: {
        //假造数据
       List:[],

    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        //假造数据
        that = this;
        for (var i=1;i<11;i++){
            var topicData = {};
            topicData.text = i + ".  话题的内容"
            that.data.List.push(topicData);
        }
        that.setData({
            List:that.data.List
        })

    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    }
})