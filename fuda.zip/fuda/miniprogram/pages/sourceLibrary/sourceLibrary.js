// pages/questionLibrary/questionLibrary.js
Page({

    /**
     * 页面的初始数据
     */
    data: {
url:'',
    },
    bindViewTap: function(){
       
        wx.navigateTo({
          url: '../libraryUpload/libraryUpload'
      }) 
},

onClick: function(){
    wx.navigateTo({
      url: '../librarySearch/librarySearch'
  }) 
},


download:function(e){
     
  var url=e.currentTarget.dataset.id;
  console.log(e.currentTarget.dataset.id);


  var that = this;
  wx.setClipboardData({
    data: e.currentTarget.dataset.id,
    success(e){
      wx.showToast({
        title: 'to浏览器^v^',
      })
      
    }
  })




},
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
      console.log(options.id)
      var that=this;
      wx.cloud.database().collection('tiku').doc(options.id).get({
          success(res){
              console.log(res.data.文件doc)
          that.setData({
              action:res.data.文件doc
          })
          
          }



      })

  },
})