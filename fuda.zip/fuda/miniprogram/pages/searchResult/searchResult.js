// pages/searchResult/searchResult.js
var that;
Page({

    /**
     * 页面的初始数据
     */
    data: {
        list:[],
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        that = this;
        var topicData1 = {};
        topicData1.nickName = "好优秀";
        topicData1.title = "福州大学计算机专业怎么样？";
        topicData1.faceImg = "../../素材/头像1.jpg";
        topicData1.text = "问一下各位大佬";
        topicData1.time = "2021-11-27";
        that.data.list.push(topicData1);
        var topicData2 = {};
        topicData2.nickName = "HAM";
        topicData2.title = "福州大学城有什么好吃的烧烤";
        topicData2.faceImg = "../../素材/头像2.jpg";
        topicData2.text = "孩子太馋了";
        topicData2.time = "2021-11-26";
        that.data.list.push(topicData2);    
        var topicData3 = {};
        topicData3.nickName = "kiki";
        topicData3.title = "有人知道福州大学里面哪里拍照好看吗？";
        topicData3.faceImg = "../../素材/头像3.jpg";
        topicData3.text = "想去拍些照片，有大佬给点建议吗。";
        topicData3.time = "2021-11-26";
        that.data.list.push(topicData3);
        var topicData4 = {};
        topicData4.nickName = "HAM";
        topicData4.title = "福州大学教务处电话是多少？";
        topicData4.faceImg = "../../素材/头像2.jpg";
        topicData4.text = "如题";
        topicData4.time = "2021-11-24";
        that.data.list.push(topicData4);     
        that.setData({
            list:that.data.list
        })
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    }
})