// pages/libraryUpload/libraryUpload.js
Page({
      //上传文
      // choosemessage(){
      //   wx.chooseMessageFile({
      //     count: 1,
      //     type: 'all',
      //     success (res) {
      //       console.log("选择文件成功",res)
      //       wx.showToast({
      //         title: '文件选择成功!',
      //       })
      //     }
      //   })
      // }


      uploadword() {
        wx.chooseMessageFile({
          count: 1,
          type: 'all',
          success(res) {
            console.log(res)
            const tempFilePaths = res.tempFilePaths
            wx.cloud.uploadFile({
              cloudPath: "题库/" + res.tempFiles[0].name,
              filePath: res.tempFiles[0].path,
              success: res => {
                console.log("上传成功", res)
                wx.showToast({
                  title: '发表成功!',
                })
              },
              fail: console.error
            })
          }
        })


      }})