const app = getApp();
var that;
const util = require('../../utils/util.js');

Page({
    data: {
        huati:[],
        userInfo:{},
        showCommentAdd:true,//是否显示对评论的评论输入框
        showAddCommenttheComment:false,//是否显示对评论的评论输入框
        heightBottom:'',//键盘弹起高度
        InputValue:'',
        id:'',//话题的id

    },
    onLoad:function(options){
        that =this
        
        console.log(options.id)
       that.data.id = options.id

        wx.cloud.database().collection('enjoys').doc(options.id).get({
            success(res){
                console.log(res)
                that.setData({
                    huati:res.data
                })
            }
        })
         that = this;
         setTimeout(function(){
            console.log(app.globalData.openid)
             that.setData({
             myOpenid:app.globalData.openid
            }) 
         },2000)
        
    },
    upper:function(){
        console.log('upper');
        wx.showNavigationBarLoading();
        this.refresh();
        setTimeout(function(){
            wx.hideNavigationBarLoading();
        },1000)
    },
//
    refresh:function(){
        wx.showToast({
        title: '刷新中',
        icon:'loading',
        duration:1000
        });
    
        wx.cloud.database().collection('enjoys').doc(that.data.id).get({
            success(res){
                console.log(res)
                that.setData({
                    huati:res.data
                })
            }
        })
        setTimeout(function(){
            wx.showToast({
              title: '刷新成功',
              icon:'success',
              duration:1000
            })

        },2000)
    },


    lower:function(){
        wx.showNavigationBarLoading();
        
        this.nextLoad();
        setTimeout(function(){
            wx.hideNavigationBarLoading();
        },1000)

    },
    nextLoad:function(){
        wx.showToast({
            title: '加载中',
            icon:'loading',
            duration:1000
            });
        //这边要增加函数用来对数据进行重新设置，从而达到刷新的效果
        wx.cloud.database().collection('enjoys').doc(that.data.id).get({
            success(res){
                console.log(res)
                that.setData({
                    huati:res.data
                })
            }
        })
    
            setTimeout(function(){
                wx.showToast({
                  title: '加载成功',
                  icon:'success',
                  duration:1000
                })
    
            },2000)
    },

    bindFoucs(e){
        that.setData({
            heightBottom:e.detail.height
        })
    },



    topublishComment(){
        if(app.globalData.userInfo == null){
            wx.navigateTo({
              url: '/pages/login/login',
            })

        }else {
            that.data.userInfo = app.globalData.userInfo;
        }
    },
//获取对话题评论框的内容
    getInputValue(event){
        console.log(event.detail.value) 
        that.data.InputValue = event.detail.value
    },
    clickSendtheComment(){
        if(app.globalData.userInfo == null){
            wx.navigateTo({
              url: '/pages/login/login',
            })

        }else{
            
            // 在onload开始就获取文章的id并且也把文章内容给了huati
            // 为什么这里要再次获取？
            // 为了使得文章是实时的  防止在访问页面很久后才评论 这期间已经有其他人评论 
            //  如果没再次获取就会把别人的评论顶掉  产生bug
            console.log(that.data.id )
            wx.cloud.database().collection('enjoys').doc(that.data.id).get({
                success(res){
                    console.log(res)
                    var action = res.data
                    var comment = {}//一条评论对象
                    comment.nickName = app.globalData.userInfo.nickName
                    comment.faceImg = app.globalData.userInfo.avatarUrl
                    comment.openid = app.globalData.openid
                    comment.text = that.data.InputValue
                    comment.time = Date.now()
                    comment.time = util.formatTime(new Date(comment.time))
                    comment.toOpenid = ''
                    comment.toNickname = ''

                    action.commentList.push(comment)

                    //上传消息用于我的模块获取信息
                    var message ={}
                    message.myopenid = app.globalData.openid
                    message.docid = that.data.id
                    message.comment = that.data.InputValue
                    message.time =  comment.time
                    wx.cloud.database().collection('messages').add({
                        data:{
                            comment:message
                        },
                        success(res){
                            console.log(res)
                        },
                        
                        
                    })
                    that.data.InputValue =''
                    // document.getElementById("comment-input").value="";
                    // console.log('输入框内容',that.data.InputValue)
                    //更新数据库
                    wx.cloud.database().collection('enjoys').doc(that.data.id).update({
                 
                        data:{
                            commentList:action.commentList
                        },
                        success(res){
                    
                            console.log(res)
                            wx.navigateBack({
                              delta: 0,
                            })
                            wx.showToast({
                              title: '评论成功!',
                              duration:1000
                            })

                        },


                    }) 



                },

            })
        }

    }
   
})