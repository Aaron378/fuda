// pages/login/login.js
const app = getApp()
Page({
    getInfo(e){
    
        wx.getUserProfile({
          desc: '获取用户必要信息',
          success(res){
              console.log(res)
              app.globalData.userInfo = res.userInfo; 

              // 上传user
              wx.cloud.database().collection('users-login').add({
                data:{
                  Name:app.globalData.userInfo.nickName,
                  face:app.globalData.userInfo.avatarUrl,
                },
                success(res){
                  console.log(res)
                  wx.cloud.database().collection('users-login').where({_id:res._id}).get({
                    success(res){
                      app.globalData.opendid = res.data[0]._openid,
                      console.log(res.data[0]._openid)
                    }
                  })
                }
              }),
              // wx.switchTab({
              //   url: '/pages/users/users',
              // })


              //返回上一个页面
              wx.navigateBack({
                success(res){
                     wx.showToast({
                      title: '授权成功!',
                    })
                }
              })





          }
        })
        
        


    }
})