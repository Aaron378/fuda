// pages/enjoy/enjoy.js
//假造数据
var that = this;
const app = getApp();
Page({
    toEssay(){
        wx.navigateTo({
          url: '/pages/essay/essay',
        })
    },
    data: {
       //假造数据
       List:[],
    },

    onLoad: function (options) {
      
        // //假造数据
        // that = this;
        // for (var i=1;i<11;i++){
        //     var topicData = {};
        //     topicData.text = i + ".  话题的内容"
        //     that.data.List.push(topicData);
        // }
        // that.setData({
        //     List:that.data.List
        // })
        let that = this
    wx.cloud.callFunction({
      name: "getlist1",
      success(res) {
        console.log("请求成功", res)
        res.result.data.forEach(item => {
          var tim = item.time
          var d = new Date(tim);
          var year = d.getFullYear();
          var month = (d.getMonth() + 1) < 10 ? "0" + (d.getMonth() + 1) : (d.getMonth() + 1)
          var day = d.getDate()
          var hour = d.getHours()
          var minute = d.getMinutes() < 10 ? "0" + d.getMinutes() : d.getMinutes()
          var second = d.getSeconds() < 10 ? "0" + d.getSeconds() : d.getSeconds()
          var time = year + "-" + month + "-" + day
          item.time = time
        })
        that.setData({
          actionsList: res.result.data
        })
      },
      fail(err) {
        console.log("请求no", err)
      }
    })

    that = this
        wx.cloud.database().collection('enjoys').get({
            success(res){
                console.log(res)
                console.log(res.data)
                that.setData({
                    jinrihuati:res.data
                })
            }
        })
    },
    tomyanswer(e){
        wx.navigateTo({
          url: '../essayenjoy/essayenjoy?id='+e.currentTarget.dataset.id,
        })
    }




    

})