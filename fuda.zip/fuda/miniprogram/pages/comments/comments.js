// pages/comments/comments.js
const app = getApp()
var that;
const util = require('../../utils/util.js');

Page({
    data: {
        huati:[],
        userInfo:{},
        showCommentAdd:true,//是否显示对评论的评论输入框
        showAddCommenttheComment:false,//是否显示对评论的评论输入框
        heightBottom:'',//键盘弹起高度
        InputValue:'',
        id:'',//话题的id

    },
    onLoad:function(options){
        that =this
        
        //从文章页面获取文章的id
        // 这边假写数据
        // options.id="859059a5619b93e8076a58da24fa029c"
        console.log(options.id)
       that.data.id = options.id

        wx.cloud.database().collection('actions').doc(options.id).get({
            success(res){
                console.log(res)
                that.setData({
                    huati:res.data
                })
            }
        })
         that = this;
         setTimeout(function(){
            console.log(app.globalData.openid)
             that.setData({
             myOpenid:app.globalData.openid
            }) 
         },2000)
        
    },
    // getActionsList(){
    //     that = this
    //     wx.cloud.database().collection('actions').orderBy('time','desc').get({
    //         success(res){
    //             console(res)
    //             // //格式化时间
    //             // var priseList = res.data.priseList
    //             // for(var l in priseList){
    //             //     if(priseList)
    //             //     priseList[l].time = util.formatTime(new Date(priseList[l].time))
    //             // }


    //         }
    //     })
    // }
    
//  上滑刷新函数
    upper:function(){
        console.log('upper');
        wx.showNavigationBarLoading();
        this.refresh();
        setTimeout(function(){
            wx.hideNavigationBarLoading();
        },1000)
    },
//
    refresh:function(){
        wx.showToast({
        title: '刷新中',
        icon:'loading',
        duration:1000
        });
    
        wx.cloud.database().collection('actions').doc(that.data.id).get({
            success(res){
                console.log(res)
                that.setData({
                    huati:res.data
                })
            }
        })
        setTimeout(function(){
            wx.showToast({
              title: '刷新成功',
              icon:'success',
              duration:1000
            })

        },2000)
    },


    lower:function(){
        wx.showNavigationBarLoading();
        
        this.nextLoad();
        setTimeout(function(){
            wx.hideNavigationBarLoading();
        },1000)

    },
    nextLoad:function(){
        wx.showToast({
            title: '加载中',
            icon:'loading',
            duration:1000
            });
        //这边要增加函数用来对数据进行重新设置，从而达到刷新的效果
        wx.cloud.database().collection('actions').doc(that.data.id).get({
            success(res){
                console.log(res)
                that.setData({
                    huati:res.data
                })
            }
        })
    
            setTimeout(function(){
                wx.showToast({
                  title: '加载成功',
                  icon:'success',
                  duration:1000
                })
    
            },2000)
    },

//评论函数
    // toComment(){
    //     if(app.globalData.userInfo == null){
    //         wx.navigateTo({
    //           url: '/pages/login/login',
    //         })

    //     }else {
    //         that.data.userInfo = app.globalData.userInfo;
    //          //console.log(that.data.userInfo);
    //         // 跳转到tabbr页面必须用switchTab 
    //         // wx.switchTab({
    //         //   url: '/pages/index/index',
    //         // })

    //     }

    // },

    // clickComment(e){
    //     that.setData({
    //         currentCircleIndex:e.currentTarget.dataset.index,
    //         showCommentAdd:false,
    //         showAddCommenttheComment:true
    //     })
    //     // console.log(e.currentTarget.dataset.index);
    // },
    // clickLove(e){

    //     var index = e.currentTarget.dataset.index;
    //     var circleData = that.data.list[index];
    //     var loveList = circleData.loveList;

    //     var isHaveLove = false;
    //     for(var i = 0; i<loveList.length; i++){
    //         if(that.data.userInfo.nickName == loveList[i].nickName){
    //             isHaveLove = true ;
    //             loveList.splice(i,1);
    //             console.log("unclick");
    //             break;
    //         }
    //     }

    //     if(!isHaveLove){
    //         loveList.push({nickName:that.data.userInfo.nickName});
    //         console.log("click");
    //     }
    //     that.setData({
    //         list:that.data.list
    //     })
    // },
    // bindInput(e){
    //     that.setData({
    //         commentContent:e.detail.value
    //     })
    // },
    bindFoucs(e){
        that.setData({
            heightBottom:e.detail.height
        })
    },
    // clickSend(e){
    //     if(app.globalData.userInfo == null){
    //         wx.navigateTo({
    //           url: '/pages/login/login',
    //         })
    //     }else{

    //         wx.cloud.database().collection('actions').doc(that.data.id).get({
    //             success(res){
    //                 console.log(res)
    //                 var commentcommentList = res.data.commentList[that.data.currentCircleIndex]
    //                 var comment = {}//一条评论对象
    //                 comment.nickName = app.globalData.userInfo.nickName
    //                 comment.faceImg = app.globalData.userInfo.avatarUrl
    //                 comment.openid = app.globalData.openid
    //                 comment.text = that.data.InputValue
    //                 comment.time = Date.now()
    //                 comment.time = util.formatTime(new Date(comment.time))
    //                 comment.toOpenid = ''
    //                 comment.toNickname = ''
    //                 commentcommentList.push(comment)
                    
    //                 //更新数据库
    //                 wx.cloud.database().collection('actions').doc(that.data.id).update({
    //                     data:{
    //                         commentList:commentcommentList.commentList
    //                     },
    //                     success(res){
    //                         console.log(res)
    //                         wx.showToast({
    //                           title: '评论成功!',
    //                           duration:1000
    //                         })
    //                     },
                        
                        
    //                 })
                    
    //             },
    //         })
    //     }


    //     // var circleData = that.data.list[that.data.currentCircleIndex];
    //     // var commentList = circleData.commentList;

    //     // var commentData = {}
    //     // console.log(that.data.userInfo.nickName);
    //     // commentData.nickName = that.data.userInfo.nickName + ":";
    //     // var comment_time = util.formatTime(new Date());
    //     // commentData.time =  comment_time;
    //     // commentData.content = that.data.commentContent;

    //     // commentList.push(commentData);
    //     that.setData({
    //         list:that.data.list,
    //         showCommentAdd:true,
    //         showAddCommenttheComment:false,
    //         commentContent:''
    //     })
    // },



    topublishComment(){
        if(app.globalData.userInfo == null){
            wx.navigateTo({
              url: '/pages/login/login',
            })

        }else {
            that.data.userInfo = app.globalData.userInfo;
            //  console.log(that.data.userInfo);
            // 跳转到tabbr页面必须用switchTab 
            // wx.switchTab({
            //   url: '/pages/index/index',
            // })

        }
    },
//获取对话题评论框的内容
    getInputValue(event){
        console.log(event.detail.value) 
        that.data.InputValue = event.detail.value
    },
    clickSendtheComment(){
        if(app.globalData.userInfo == null){
            wx.navigateTo({
              url: '/pages/login/login',
            })

        }else{
            
            // 在onload开始就获取文章的id并且也把文章内容给了huati
            // 为什么这里要再次获取？
            // 为了使得文章是实时的  防止在访问页面很久后才评论 这期间已经有其他人评论 
            //  如果没再次获取就会把别人的评论顶掉  产生bug
            console.log(that.data.id )
            wx.cloud.database().collection('actions').doc(that.data.id).get({
                success(res){
                    console.log(res)
                    var action = res.data
                    var comment = {}//一条评论对象
                    comment.nickName = app.globalData.userInfo.nickName
                    comment.faceImg = app.globalData.userInfo.avatarUrl
                    comment.openid = app.globalData.openid
                    comment.text = that.data.InputValue
                    comment.time = Date.now()
                    comment.time = util.formatTime(new Date(comment.time))
                    comment.toOpenid = ''
                    comment.toNickname = ''

                    action.commentList.push(comment)

                    //上传消息用于我的模块获取信息
                    var message ={}
                    message.myopenid = app.globalData.openid
                    message.docid = that.data.id
                    message.comment = that.data.InputValue
                    message.time =  comment.time
                    wx.cloud.database().collection('messages').add({
                        data:{
                            comment:message
                        },
                        success(res){
                            console.log(res)
                        },
                        
                        
                    })
                    that.data.InputValue =''
                    // document.getElementById("comment-input").value="";
                    // console.log('输入框内容',that.data.InputValue)
                    //更新数据库
                    wx.cloud.database().collection('actions').doc(that.data.id).update({
                        data:{
                            commentList:action.commentList
                        },
                        success(res){
                    
                            console.log(res)
                            wx.navigateBack({
                              delta: 0,
                            })
                            wx.showToast({
                              title: '评论成功!',
                              duration:1000
                            })

                        },


                    }) 



                },

            })
        }

    }


  



   
})