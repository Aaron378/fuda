// pages/topicPost/topicPost.js
const app = getApp()
Page({

    /**     * 页面的初始数据     */
    data: {
        title:null,
        text:null,
    },

    gettitleinput(e){
        console.log(e.detail.value)
        this.setData({
            title:e.detail.value
        })
    },
    gettextinput(e){
        console.log(e.detail.value)
        this.setData({
            text:e.detail.value
        })
    },
    // 上传数据到云服务器
    submitData(){
        wx.cloud.database().collection('actions').add({
            data:{
                nickName:app.globalData.userInfo.nickName,
                faceImg:app.globalData.userInfo.avatarUrl,
                title:this.data.title,
                commentList:[],
                priceList:[],
                text:this.data.text,
                time: Date.now(),
            },
            success(res){
                console.log(res)
               //返回上一个页面
              wx.navigateBack({
                success(res){
                     wx.showToast({
                      title: '发表成功!',
                    })
                }
              })
            }
        })
    }
})